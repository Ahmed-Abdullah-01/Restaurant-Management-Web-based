<?php
require_once('dbcontroller.php');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$errors = [];

try {
    $db = new DBController();
    
    // Check if database connection is successful
    if (!$db->isConnected()) {
        throw new Exception("Database connection failed");
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        // Validation
        if (empty($email)) {
            $errors[] = "Email is required";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        }

        if (empty($password)) {
            $errors[] = "Password is required";
        }

        if (empty($errors)) {
            // Get user from database using prepared statement
            $query = "SELECT * FROM customer WHERE email = ?";
            $user = $db->runQuery($query, [$email], "s");

            if ($user && count($user) > 0) {
                $stored_password = $user[0]['password'];

                if (password_verify($password, $stored_password)) {
                    // Modern hash match
                    $_SESSION['customer_id'] = $user[0]['cust_id'];
                    $_SESSION['customer_name'] = $user[0]['name'];
                    $_SESSION['email'] = $user[0]['email'];
                    
                    // Update last login time
                    $update_query = "UPDATE customer SET last_login = CURRENT_TIMESTAMP WHERE cust_id = ?";
                    $db->runQuery($update_query, [$user[0]['cust_id']], "i");
                    
                    error_log("Login success: " . $email);
                    header("Location: index.php");
                    exit();
                } elseif (md5($password) === $stored_password) {
                    // Legacy md5 match
                    $new_hash = password_hash($password, PASSWORD_DEFAULT);
                    $update_query = "UPDATE customer SET password = ?, last_login = CURRENT_TIMESTAMP WHERE cust_id = ?";
                    $db->runQuery($update_query, [$new_hash, $user[0]['cust_id']], "si");

                    $_SESSION['customer_id'] = $user[0]['cust_id'];
                    $_SESSION['customer_name'] = $user[0]['name'];
                    $_SESSION['email'] = $user[0]['email'];
                    
                    error_log("Login with hash upgrade: " . $email);
                    header("Location: index.php");
                    exit();
                } else {
                    $errors[] = "Invalid email or password";
                    error_log("Failed login attempt for user: " . $email);
                }
            } else {
                $errors[] = "Invalid email or password";
                error_log("Login attempt for non-existent user: " . $email);
            }
        }
    }
} catch (Exception $e) {
    $errors[] = "An error occurred. Please try again.";
    error_log("Login error: " . $e->getMessage());
}
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
    <link rel="stylesheet" href="./css/style1.css">
    <title>Login</title>
</head>

<body>
    <div class="container" id="container">
        <div class="form-container sign-in-container">
            <?php if (!empty($errors)): ?>
                <div class="alert error">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="post" name="login">
                <h1>Sign in</h1>
                <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required />
                <input type="password" name="password" placeholder="Password" required />
                <a href="#">Forgot your password?</a>
                <button type="submit">Login</button>
                <p>Not registered yet? <a href="registration.php" style="color:#FF0000;font-weight:bold;">Register Here</a></p>
            </form>
        </div>
    </div>

    <div class="landing"> <!---background-->
        <div class="opac">
        </div>
    </div>

    <footer>
        <p>
            Created with <i class="fa fa-heart"></i> by
            <a target="_blank" href="index.html">FOODILITE</a>
        </p>
    </footer>
    <script src="./js/main.js"></script>
</body>

</html>
