<?php
require_once('dbcontroller.php');

$db = new DBController();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');

    // Validate input
    $errors = [];
    
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    
    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }
    
    if (empty($password)) {
        $errors[] = "Password is required";
    } elseif (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters long";
    }

    if (empty($phone)) {
        $errors[] = "Phone number is required";
    } elseif (!preg_match("/^[0-9]{10}$/", $phone)) {
        $errors[] = "Phone number must be 10 digits";
    }

    if (empty($address)) {
        $errors[] = "Address is required";
    }

    // Check if email already exists
    $check_email = $db->runQuery("SELECT COUNT(*) as count FROM customer WHERE email = ?", [$email], "s");
    if ($check_email && $check_email[0]['count'] > 0) {
        $errors[] = "Email address is already registered. Please use a different email or try logging in.";
    }

    if (empty($errors)) {
        // Hash password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Insert new user with phone and address
        $query = "INSERT INTO customer (name, email, password, phone, address) VALUES (?, ?, ?, ?, ?)";
        $result = $db->runQuery($query, [$name, $email, $hashed_password, $phone, $address], "sssss");

        if ($result) {
            $_SESSION['success'] = "Registration successful! Please login.";
            header("Location: login.php");
            exit();
        } else {
            $errors[] = "Registration failed. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">
    <link rel="stylesheet" href="./css/style1.css">
    <title>Registration</title>
</head>
<body>
    <div data-aos="fade-down" class="container" id="container">
        <div class="form-container sign-up-container">
            <?php if (!empty($errors)): ?>
                <div class="alert error">
                    <?php foreach ($errors as $error): ?>
                        <p><?= htmlspecialchars($error) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <form method="post" name="registration">
                <h1 style="padding-bottom: 20px">Create Account</h1>
                <input type="text" name="name" placeholder="Full Name" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required />
                <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required />
                <input type="password" name="password" placeholder="Password" required />
                <input type="tel" name="phone" placeholder="Phone Number (10 digits)" pattern="[0-9]{10}" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required />
                <textarea name="address" placeholder="Address" required><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
                <span style="padding-top: 10px"><button>Sign Up</button></span>
                <p>Already have an account? <a href='login.php' style="color:#FF0000;font-weight:bold;">Login Here</a></p>
            </form>
        </div>
    </div>

    <div class="landing"> <!---background-->
        <div class="opac">
        </div>
    </div>

    <footer>
        <p>
            Created with <i class="fa fa-heart"></i> by
            <a target="_blank" href="index.html">FOODILITE</a>
        </p>
    </footer>
    <script src="./js/main.js"></script>
</body>
</html>