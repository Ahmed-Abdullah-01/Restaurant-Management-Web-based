<?php
require_once('adminauth.php');
require_once('../dbcontroller.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$db = new DBController();

if (!isset($_GET['cat_id'])) {
    $_SESSION['error'] = "No category ID provided.";
    header("Location: categories.php");
    exit();
}

$cat_id = (int)$_GET['cat_id'];

// Check if the category has associated items in the 'menu' table
$check = $db->runQuery("SELECT COUNT(*) as count FROM menu WHERE cat_id = " . $cat_id);

if ($check && $check[0]['count'] > 0) {
    $_SESSION['error'] = "Cannot delete category because it has menu items associated with it. Please reassign or delete the menu items first.";
    header("Location: categories.php");
    exit();
}

// Delete category
$result = $db->runQuery("DELETE FROM categories WHERE cat_id = " . $cat_id);

if ($result) {
    $_SESSION['success'] = "Category deleted successfully.";
} else {
    $_SESSION['error'] = "Deletion failed. Please make sure there are no menu items associated with this category.";
}

header("Location: categories.php");
exit();
