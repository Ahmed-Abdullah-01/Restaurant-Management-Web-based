<?php
require('../db.php');
include("adminauth.php");

// Start session for error messages
session_start();

// Validate customer ID
if (!isset($_GET['id']) || !ctype_digit($_GET['id'])) {
    $_SESSION['error'] = "Invalid customer ID";
    header("Location: adview.php");
    exit();
}

$cust_id = (int)$_GET['id'];

try {
    // Check if customer exists first
    $check_sql = "SELECT cust_id FROM customer WHERE cust_id = ?";
    $check_stmt = mysqli_prepare($con, $check_sql);
    mysqli_stmt_bind_param($check_stmt, 'i', $cust_id);
    mysqli_stmt_execute($check_stmt);
    mysqli_stmt_store_result($check_stmt);

    if (mysqli_stmt_num_rows($check_stmt) === 0) {
        $_SESSION['error'] = "Customer not found";
        header("Location: adview.php");
        exit();
    }

    // Proceed with deletion
    $delete_sql = "DELETE FROM customer WHERE cust_id = ?";
    $delete_stmt = mysqli_prepare($con, $delete_sql);
    mysqli_stmt_bind_param($delete_stmt, 'i', $cust_id);

    if (mysqli_stmt_execute($delete_stmt)) {
        $_SESSION['success'] = "Customer deleted successfully";
    } else {
        throw new Exception("Delete failed: " . mysqli_error($con));
    }

    // Cleanup
    mysqli_stmt_close($check_stmt);
    mysqli_stmt_close($delete_stmt);

} catch (Exception $e) {
    error_log($e->getMessage());
    $_SESSION['error'] = "Error deleting customer: " . $e->getMessage();
} finally {
    mysqli_close($con);
    header("Location: adview.php");
    exit();
}
?>
