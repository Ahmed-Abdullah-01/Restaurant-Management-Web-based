<?php
require('../db.php');
session_start();

if (isset($_POST['username'])) {
    $username = stripslashes($_REQUEST['username']);
    $username = mysqli_real_escape_string($con, $username);
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($con, $password);

    $query = "SELECT * FROM `admin` WHERE username='$username' and password='" . md5($password) . "'";
    $result = mysqli_query($con, $query) or die(mysqli_error($con));
    $rows = mysqli_num_rows($result);

    if ($rows == 1) {
        $_SESSION['username'] = $username;
        header("Location: control.php");
        exit();
    } else {
        $error = "Username or password is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Admin Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="../css/login_options.css">
</head>
<body>
    <div class="landing">
        <div class="opac"></div>
    </div>

    <div class="container">
        <div class="form-container sign-in-container">
            <form method="post" name="admin">
                <h1>Admin Login</h1>
                <?php if (!empty($error)) { echo "<p style='color: red;'>$error</p>"; } ?>
                <input type="text" name="username" placeholder="Username" required />
                <input type="password" name="password" placeholder="Password" required />
                <a href="#">Forgot your password?</a>
                <span><button type="submit">Login</button></span>
                <p>Not registered yet? <a href='../registration.php'>Register Here</a></p>
            </form>
        </div>
    </div>

    <footer>
        <p>
            Created with <i class="fa fa-heart"></i> by
            <a href="../index.html" target="_blank">Foodilite</a>
        </p>
    </footer>
</body>
</html>
