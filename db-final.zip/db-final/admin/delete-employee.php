<?php
require_once('../dbcontroller.php');
require_once('adminauth.php');

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$db = new DBController();

if (!$db->isConnected()) {
    $_SESSION['error'] = "Database connection failed";
    header("Location: adminview-employees.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    try {
        // Delete directly without existence check (let database handle it)
        $affected_rows = $db->prepareQuery(
            "DELETE FROM employee WHERE id = ?", 
            [$id], 
            "i"
        );

        if ($affected_rows === false) {
            throw new Exception("Database operation failed");
        }

        if ($affected_rows > 0) {
            $_SESSION['success'] = "Employee deleted successfully";
        } else {
            $_SESSION['error'] = "Employee not found";
        }
    } catch (Exception $e) {
        $error = $db->conn->error ?: $e->getMessage();
        $_SESSION['error'] = "Deletion failed: " . htmlspecialchars($error);
        error_log("DELETE ERROR: " . $error);
    }
} else {
    $_SESSION['error'] = "Invalid employee ID";
}

header("Location: adminview-employees.php");
exit();
?>