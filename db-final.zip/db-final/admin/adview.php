<?php
require('../db.php');
include("adminauth.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Customers</title>
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        /* Neutral Dark Theme Customer Table Styles */
        .customer-table {
            margin-top: 2rem;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            background: #1a1a1a;
            color: #e0e0e0;
            border: 1px solid #333;
        }

        .customer-table th {
            background: #2d2d2d;
            color: #e0e0e0;
            padding: 15px 20px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #333;
        }

        .customer-table td {
            padding: 12px 20px;
            vertical-align: middle;
            border-bottom: 1px solid #333;
        }

        .customer-table tr:nth-child(even) {
            background-color: #2d2d2d;
        }

        .customer-table tr:hover {
            background-color: #333;
            transition: background 0.3s ease;
        }

        .action-btns {
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        .badge {
            background: #333;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: 500;
            font-size: 0.9em;
        }

        /* Neutral Dark Theme Buttons */
        .btn-primary {
            background: #333;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 5px;
            transition: transform 0.2s ease;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }

        .btn-danger {
            background: #333;
            color: white;
            border: none;
            padding: 8px 20px;
            border-radius: 5px;
            transition: transform 0.2s ease;
        }

        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }

        /* Neutral Dark Theme Alerts */
        .success-alert,
        .error-alert {
            background: #2d2d2d;
            color: #e0e0e0;
            border: 1px solid #333;
            padding: 15px;
            border-radius: 6px;
            margin: 20px 0;
        }
    </style>
</head>

<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>

        <!-- Main Content Area -->
        <div class="admin-content">
            <div class="content-header">
                <h1 class="content-title">Customer Records</h1>
                <p class="content-description">View and manage customer information.</p>
            </div>

            <?php
            if (isset($_SESSION['error'])) {
                echo "<div class='error'>" . $_SESSION['error'] . "</div>";
                unset($_SESSION['error']);
            }
            if (isset($_SESSION['success'])) {
                echo "<div class='success'>" . $_SESSION['success'] . "</div>";
                unset($_SESSION['success']);
            }
            ?>

            <div class="table-container">
                <table class="customer-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Location</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $count = 1;
                        $sel_query = "SELECT * FROM customer ORDER BY cust_id ASC";
                        $result = mysqli_query($con, $sel_query);
                        while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr>
                                <td class="badge"><?php echo $count; ?></td>
                                <td><?php echo htmlspecialchars($row["name"]); ?></td>
                                <td><?php echo htmlspecialchars($row["email"]); ?></td>
                                <td><?php echo htmlspecialchars($row["phone"]); ?></td>
                                <td><?php echo htmlspecialchars($row["address"]); ?></td>
                                <td class="action-btns">
                                    <a href="edit_customer.php?id=<?php echo $row["cust_id"]; ?>" 
                                       class="btn btn-primary btn-icon">
                                        ✏️ Edit
                                    </a>
                                    <a href="addelete.php?id=<?php echo $row["cust_id"]; ?>" 
                                       class="btn btn-danger btn-icon"
                                       onclick="return confirm('Are you sure you want to delete this record?')">
                                        🗑️ Delete
                                    </a>
                                </td>
                            </tr>
                        <?php $count++; } ?>
                    </tbody>
                </table>
            </div>
            
            <div class="table-footer">
                <p class="record-count">Showing <?php echo ($count-1); ?> customer records</p>
                <a href="adinsert.php" class="btn btn-primary btn-icon">
                    ➕ Add New Customer
                </a>
            </div>
        </div>
    </div>

    <script src="js/admin.js"></script>
</body>
</html>
