<?php
require_once('adminauth.php');
require_once('../dbcontroller.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$db = new DBController();

// Handle category add/update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $cat_id = isset($_POST['cat_id']) ? (int)$_POST['cat_id'] : null;

    if ($cat_id) {
        // Update
        $result = $db->runQuery("UPDATE categories SET name = '" . $db->sanitize($name) . "' WHERE cat_id = " . $cat_id);
        $_SESSION[$result ? 'success' : 'error'] = $result ? "Category updated successfully." : "Failed to update category.";
    } else {
        // Add
        $result = $db->runQuery("INSERT INTO categories (name) VALUES ('" . $db->sanitize($name) . "')");
        $_SESSION[$result ? 'success' : 'error'] = $result ? "Category added successfully." : "Failed to add category.";
    }

    header("Location: categories.php");
    exit();
}

// Fetch all categories
$categories = $db->runQuery("SELECT * FROM categories ORDER BY name");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Categories</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>
        <div class="admin-content">
            <h1>Manage Categories</h1>
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <!-- Add Form -->
            <form method="POST" class="form">
                <label>Category Name</label>
                <input type="text" name="name" required>
                <button type="submit" class="btn btn-primary">Add Category</button>
            </form>

            <!-- List -->
            <table class="data-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($categories): foreach ($categories as $cat): ?>
                        <tr>
                            <td><?= $cat['cat_id']; ?></td>
                            <td><?= htmlspecialchars($cat['name']); ?></td>
                            <td>
                                <button onclick="editCategory(<?= $cat['cat_id']; ?>, '<?= htmlspecialchars($cat['name']); ?>')" class="btn btn-primary btn-icon">✏️ Edit</button>
                                <a href="delete_category.php?cat_id=<?= $cat['cat_id']; ?>" class="btn btn-danger btn-icon" onclick="return confirm('Are you sure you want to delete this category?')">🗑️ Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; else: ?>
                        <tr><td colspan="3">No categories found</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal" style="display: none;">
        <div class="modal-content">
            <h2>Edit Category</h2>
            <form method="POST" class="form">
                <input type="hidden" name="cat_id" id="edit_cat_id">
                <div class="form-group">
                    <label>Category Name</label>
                    <input type="text" name="name" id="edit_name" required>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Update</button>
                    <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <style>
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 1000;
        }
        .modal-content {
            background-color: #1a1a1a;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #333;
            width: 50%;
            max-width: 500px;
            border-radius: 8px;
        }
        .form-actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
    </style>

    <script>
        function editCategory(catId, name) {
            document.getElementById('edit_cat_id').value = catId;
            document.getElementById('edit_name').value = name;
            document.getElementById('editModal').style.display = 'block';
        }

        function closeModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target == document.getElementById('editModal')) {
                closeModal();
            }
        }
    </script>
</body>
</html>
