<?php
require_once('../dbcontroller.php');
require_once('adminauth.php');

$db = new DBController();

// Get all categories
$categories = $db->runQuery("SELECT * FROM categories ORDER BY name");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $name = $_POST['name'];
        $cat_id = $_POST['cat_id'];
        $price = (float)$_POST['price'];
        $description = $_POST['description'];
        $image = '';

        // Handle image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $target_dir = "../images/menu/";
            if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
            
            $file_extension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
            $image = uniqid() . '.' . $file_extension;
            $target_file = $target_dir . $image;
            
            if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                throw new Exception("Error uploading image");
            }
        }

        $stmt = $db->prepareQuery(
            "INSERT INTO menu (name, cat_id, price, description, image) VALUES (?, ?, ?, ?, ?)",
            [$name, $cat_id, $price, $description, $image],
            "sidss"
        );

        $_SESSION['success'] = "Menu item added successfully";
        header("Location: menu-list.php");
        exit();

    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        header("Location: menu-add.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Menu Item</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>

        <div class="admin-content">
            <div class="content-header">
                <h1 class="content-title">Add Menu Item</h1>
                <p class="content-description">Add a new item to the menu.</p>
            </div>

            <?php if (isset($_SESSION['error'])): ?>
                <div class='error'><?= htmlspecialchars($_SESSION['error']) ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name">Item Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>

                    <div class="form-group">
                        <label for="cat_id">Category</label>
                        <select id="cat_id" name="cat_id" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= htmlspecialchars($category['cat_id']) ?>">
                                    <?= htmlspecialchars($category['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                            
                    </div>

                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="number" id="price" name="price" step="0.01" min="0" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4" required></textarea>
                    </div>

                    <div class="form-group">
                        <label for="image">Image</label>
                        <input type="file" id="image" name="image" accept="image/*">
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Add Menu Item</button>
                        <a href="menu-list.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>