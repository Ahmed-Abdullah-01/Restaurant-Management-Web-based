// Sidebar toggle functionality
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const adminContent = document.querySelector('.admin-content');
    sidebar.classList.toggle('collapsed');
    
    // Update content margin when sidebar is toggled
    if (sidebar.classList.contains('collapsed')) {
        adminContent.style.marginLeft = '0';
        adminContent.style.width = '100%';
    } else {
        adminContent.style.marginLeft = '280px';
        adminContent.style.width = 'calc(100% - 280px)';
    }
}

// Handle initial state on mobile
function handleMobileView() {
    const sidebar = document.querySelector('.sidebar');
    const adminContent = document.querySelector('.admin-content');
    if (window.innerWidth <= 768) {
        sidebar.classList.add('collapsed');
        adminContent.style.marginLeft = '0';
        adminContent.style.width = '100%';
    } else {
        sidebar.classList.remove('collapsed');
        adminContent.style.marginLeft = '280px';
        adminContent.style.width = 'calc(100% - 280px)';
    }
}

// Call on page load
document.addEventListener('DOMContentLoaded', handleMobileView);

// Call on window resize
window.addEventListener('resize', handleMobileView); 