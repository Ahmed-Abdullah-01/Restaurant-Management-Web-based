<?php
require_once('adminauth.php');
require_once('../dbcontroller.php');

$db = new DBController();

// Initialize employees array
$employees = [];

// Get all employees with error handling
$result = $db->runQuery("SELECT * FROM employee ORDER BY name");
if ($result !== false) {
    $employees = $result;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Employees</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>

        <!-- Main Content Area -->
        <div class="admin-content">
            <div class="content-header">
                <h1 class="content-title">Manage Employees</h1>
                <p class="content-description">View and manage employee records.</p>
            </div>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?php 
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Position</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($employees)): ?>
                            <?php foreach($employees as $employee): ?>
                                <tr>
                                    <td><?php echo $employee['id']; ?></td>
                                    <td><?php echo $employee['name']; ?></td>
                                    <td><?php echo $employee['email']; ?></td>
                                    <td><?php echo $employee['phone']; ?></td>
                                    <td><?php echo $employee['position']; ?></td>
                                    <td>
                                        <a href="edit-employee.php?id=<?php echo $employee['id']; ?>" class="btn btn-primary btn-icon">✏️ Edit</a>
                                        <a href="delete-employee.php?id=<?php echo $employee['id']; ?>" class="btn btn-danger btn-icon" onclick="return confirm('Are you sure you want to delete this employee?')">🗑️ Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center">No employees found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="table-footer">
                <p>Showing <?php echo count($employees); ?> employees</p>
                <a href="adminadd-employee.php" class="btn btn-primary">Add New Employee</a>
            </div>
        </div>
    </div>

    <script src="js/admin.js"></script>
</body>
</html>
