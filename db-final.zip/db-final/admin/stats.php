<?php
require_once('adminauth.php');
require_once('../dbcontroller.php');

$db = new DBController();

// Get total counts with null checks
$total_customers = $db->runQuery("SELECT COUNT(*) as count FROM customer");
$total_customers = $total_customers ? $total_customers[0]['count'] : 0;

$total_employees = $db->runQuery("SELECT COUNT(*) as count FROM employee");
$total_employees = $total_employees ? $total_employees[0]['count'] : 0;

$total_menu_items = $db->runQuery("SELECT COUNT(*) as count FROM menu");
$total_menu_items = $total_menu_items ? $total_menu_items[0]['count'] : 0;

$total_orders = $db->runQuery("SELECT COUNT(*) as count FROM orders");
$total_orders = $total_orders ? $total_orders[0]['count'] : 0;

$total_revenue = $db->runQuery("SELECT SUM(total) as total FROM orders");
$total_revenue = $total_revenue ? ($total_revenue[0]['total'] ?? 0) : 0;

// Get most sold menu items
$most_sold_items = $db->runQuery("
    SELECT m.name, SUM(oi.quantity) AS order_count
    FROM order_items oi
    JOIN menu m ON oi.menu_code = m.code
    GROUP BY m.name
    ORDER BY order_count DESC
    LIMIT 5
");

// Get recent orders
$recent_orders = $db->runQuery("
    SELECT o.*, c.name as customer_name
    FROM orders o
    LEFT JOIN customer c ON o.cust_id = c.cust_id
    ORDER BY o.order_date DESC
    LIMIT 5
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>

        <!-- Main Content Area -->
        <div class="admin-content">
            <div class="content-header">
                <h1 class="content-title">Dashboard</h1>
                <p class="content-description">Welcome to the admin dashboard.</p>
            </div>

            <!-- Total Counts -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-info">
                        <h3>Total Customers</h3>
                        <p><?php echo number_format($total_customers); ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">👨‍🍳</div>
                    <div class="stat-info">
                        <h3>Total Employees</h3>
                        <p><?php echo number_format($total_employees); ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🍽️</div>
                    <div class="stat-info">
                        <h3>Menu Items</h3>
                        <p><?php echo number_format($total_menu_items); ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📦</div>
                    <div class="stat-info">
                        <h3>Total Orders</h3>
                        <p><?php echo number_format($total_orders); ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">💰</div>
                    <div class="stat-info">
                        <h3>Total Revenue</h3>
                        <p>$<?php echo number_format($total_revenue, 2); ?></p>
                    </div>
                </div>
            </div>

            <!-- Most Sold Menu Items -->
            <div class="most-sold-items">
                <h2>Most Sold Menu Items</h2>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Item Name</th>
                                <th>Orders Count</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($most_sold_items): ?>
                                <?php foreach ($most_sold_items as $item): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                                        <td><?php echo $item['order_count']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="2" class="text-center">No menu items found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Recent Orders -->
            <div class="recent-orders">
                <h2>Recent Orders</h2>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Amount</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($recent_orders): ?>
                                <?php foreach ($recent_orders as $order): ?>
                                    <tr>
                                        <td>#<?php echo $order['id']; ?></td>
                                        <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                                        <td>$<?php echo number_format($order['total'], 2); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($order['order_date'])); ?></td>
                                        <td>
                                            <span class="status-badge <?php echo strtolower($order['status']); ?>">
                                                <?php echo ucfirst($order['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">No recent orders found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="js/admin.js"></script>
</body>
</html>
