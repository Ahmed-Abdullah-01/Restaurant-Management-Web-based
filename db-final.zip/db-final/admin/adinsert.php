<?php
require('../db.php');
include("adminauth.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize form inputs
    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $phone = mysqli_real_escape_string($con, $_POST['phone']);
    $address = mysqli_real_escape_string($con, $_POST['address']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Validate form inputs
    if (empty($name) || empty($email) || empty($phone) || empty($address) || empty($_POST['password'])) {
        $_SESSION['error'] = "All fields are required.";
        header("Location: adinsert.php");
        exit();
    }

    // Check if email already exists in the database
    $check_email_sql = "SELECT * FROM customer WHERE email = ?";
    $check_email_stmt = mysqli_prepare($con, $check_email_sql);
    mysqli_stmt_bind_param($check_email_stmt, 's', $email);
    mysqli_stmt_execute($check_email_stmt);
    mysqli_stmt_store_result($check_email_stmt);

    if (mysqli_stmt_num_rows($check_email_stmt) > 0) {
        $_SESSION['error'] = "Email already exists. Please use a different email.";
        header("Location: adinsert.php");
        exit();
    }

    // Insert new customer into the database
    $insert_sql = "INSERT INTO customer (name, email, phone, address, password) VALUES (?, ?, ?, ?, ?)";
    $insert_stmt = mysqli_prepare($con, $insert_sql);
    mysqli_stmt_bind_param($insert_stmt, 'sssss', $name, $email, $phone, $address, $password);

    if (mysqli_stmt_execute($insert_stmt)) {
        $_SESSION['success'] = "New customer added successfully.";
        header("Location: adinsert.php");
        exit();
    } else {
        $_SESSION['error'] = "Failed to add new customer: " . mysqli_error($con);
        header("Location: adinsert.php");
        exit();
    }

    mysqli_stmt_close($insert_stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Customer</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar Navigation (unchanged) -->

        <div class="admin-content">
            <div class="content-header">
                <h1 class="content-title">Add New Customer</h1>
                <p class="content-description">Fill in the details to add a new customer to the system.</p>
            </div>

            <?php
            if (isset($_SESSION['error'])) {
                echo "<div class='error'>" . $_SESSION['error'] . "</div>";
                unset($_SESSION['error']);
            }
            if (isset($_SESSION['success'])) {
                echo "<div class='success'>" . $_SESSION['success'] . "</div>";
                unset($_SESSION['success']);
            }
            ?>

            <div class="form-container">
                <form action="adinsert.php" method="POST">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" name="name" id="name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" name="email" id="email" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone:</label>
                        <input type="text" name="phone" id="phone" required>
                    </div>

                    <div class="form-group">
                        <label for="address">Address:</label>
                        <input type="text" name="address" id="address" required>
                    </div>

                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" name="password" id="password" required>
                    </div>

                    <div class="action-btns">
                        <button type="submit" class="btn btn-primary btn-icon">
                            <span>➕</span>
                            Add Customer
                        </button>
                        <a href="adview.php" class="btn btn-secondary btn-icon">
                            <span>👥</span>
                            View Customers
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JavaScript remains unchanged -->
</body>
</html>