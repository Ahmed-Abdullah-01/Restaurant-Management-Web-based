<?php
require_once('adminauth.php');
require_once('../dbcontroller.php');

$db = new DBController();

// Handle delete action
if (isset($_GET['delete'])) {
    try {
        $code = intval($_GET['delete']);
        
        // First check if the item exists in any orders
        $check_orders = $db->runQuery("SELECT COUNT(*) as count FROM order_items WHERE menu_code = " . $code);
        
        if ($check_orders && $check_orders[0]['count'] > 0) {
            // Instead of deleting, mark as inactive
            $result = $db->runQuery("UPDATE menu SET is_active = 0 WHERE code = " . $code);
            if ($result) {
                $_SESSION['success'] = "Menu item has been deactivated (it exists in order history)";
            } else {
                $_SESSION['error'] = "Failed to deactivate menu item";
            }
        } else {
            // If no orders exist, proceed with deletion
            $item = $db->runQuery("SELECT image FROM menu WHERE code = " . $code);
            
            if ($item) {
                // Delete image file
                $image_path = "../images/menu/" . $item[0]['image'];
                if (file_exists($image_path)) {
                    unlink($image_path);
                }
                
                // Delete from database
                $result = $db->runQuery("DELETE FROM menu WHERE code = " . $code);
                if ($result) {
                    $_SESSION['success'] = "Menu item deleted successfully";
                } else {
                    $_SESSION['error'] = "Failed to delete menu item";
                }
            }
        }
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
    header("Location: menu-list.php");
    exit();
}

// Handle activate action
if (isset($_GET['activate'])) {
    try {
        $code = intval($_GET['activate']);
        $result = $db->runQuery("UPDATE menu SET is_active = 1 WHERE code = " . $code);
        if ($result) {
            $_SESSION['success'] = "Menu item has been reactivated";
        } else {
            $_SESSION['error'] = "Failed to reactivate menu item";
        }
    } catch (Exception $e) {
        $_SESSION['error'] = "Error: " . $e->getMessage();
    }
    header("Location: menu-list.php");
    exit();
}

// Get all menu items
$menu_items = $db->runQuery("
    SELECT m.*, c.name AS category_name 
    FROM menu m
    LEFT JOIN categories c ON m.cat_id = c.cat_id
    ORDER BY m.created_at DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Menu</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>

        <div class="admin-content">
            <div class="content-header">
                <h1 class="content-title">Manage Menu</h1>
                <p class="content-description">View and manage menu items</p>
            </div>

            <?php if(isset($_SESSION['error'])): ?>
                <div class="alert error"><?= htmlspecialchars($_SESSION['error']) ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <?php if(isset($_SESSION['success'])): ?>
                <div class="alert success"><?= htmlspecialchars($_SESSION['success']) ?></div>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($menu_items): foreach($menu_items as $item): ?>
                            <tr>
                                <td><?= $item['code'] ?></td>
                                <td><?= htmlspecialchars($item['name']) ?></td>
                                <td><?= htmlspecialchars($item['category_name']) ?></td>
                                <td>$<?= number_format($item['price'], 2) ?></td>
                                <td>
                                    <?php if($item['image']): ?>
                                        <img src="../images/menu/<?= $item['image'] ?>" alt="Item image" width="50">
                                    <?php endif; ?>
                                </td>
                                <td><?= $item['is_active'] ? 'Active' : 'Inactive' ?></td>
                                <td>
                                    <a href="menu-edit.php?code=<?= $item['code'] ?>" class="btn btn-primary">Edit</a>
                                    <?php if($item['is_active']): ?>
                                        <a href="menu-list.php?delete=<?= $item['code'] ?>" 
                                           class="btn btn-danger" 
                                           onclick="return confirm('Are you sure you want to <?= $check_orders && $check_orders[0]['count'] > 0 ? 'deactivate' : 'delete' ?> this item?')">
                                            Delete
                                        </a>
                                    <?php else: ?>
                                        <a href="menu-list.php?activate=<?= $item['code'] ?>" 
                                           class="btn btn-success" 
                                           onclick="return confirm('Are you sure you want to reactivate this item?')">
                                            Reactivate
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; else: ?>
                            <tr>
                                <td colspan="7" class="text-center">No menu items found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="table-footer">
                <a href="menu-add.php" class="btn btn-primary">Add New Item</a>
            </div>
        </div>
    </div>
</body>
</html>