<?php
require_once('adminauth.php');
require_once('../dbcontroller.php');

$db = new DBController();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>

        <!-- Main Content Area -->
        <div class="admin-content">
            <div class="content-header">
                <h1 class="content-title">Dashboard</h1>
                <p class="content-description">Welcome to the admin dashboard.</p>
            </div>
        </div>
    </div>

    <script src="js/admin.js"></script>
</body>
</html>