<?php
require_once('../dbcontroller.php');
require_once('adminauth.php');

$db = new DBController();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $position = $_POST['position'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
    $stmt = $db->prepareQuery(
        "INSERT INTO employee (name, email, phone, position, password) VALUES (?, ?, ?, ?, ?)",
        [$name, $email, $phone, $position, $password],
        "sssss"
    );
    
    if ($stmt) {
        $_SESSION['success'] = "Employee added successfully";
        header("Location: adminview-employees.php");
        exit();
    } else {
        $_SESSION['error'] = "Error adding employee";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Employee</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>

        <!-- Main Content Area -->
        <div class="admin-content">
            <div class="content-header">
                <h1 class="content-title">Add Employee</h1>
                <p class="content-description">Add a new employee to the system.</p>
            </div>

            <?php
            if (isset($_SESSION['error'])) {
                echo "<div class='error'>" . $_SESSION['error'] . "</div>";
                unset($_SESSION['error']);
            }
            ?>

            <div class="form-container">
                <form action="" method="POST" class="admin-form">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="phone" required>
                    </div>

                    <div class="form-group">
                        <label for="position">Position</label>
                        <select id="position" name="position" required>
                            <option value="">Select Position</option>
                            <option value="Manager">Manager</option>
                            <option value="Chef">Chef</option>
                            <option value="Server">Server</option>
                            <option value="Host">Host</option>
                            <option value="Kitchen Staff">Kitchen Staff</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Add Employee</button>
                        <a href="adminview-employees.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="js/admin.js"></script>
</body>
</html>