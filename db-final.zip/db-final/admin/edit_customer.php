<?php
include("adminauth.php");
require("../dbcontroller.php");
$db_handle = new DBController();
include('../db.php');

// Check if the id parameter is provided in the URL
if (isset($_GET['id'])) {
    $customer_id = $_GET['id'];

    $query = "SELECT * FROM customer WHERE cust_id = '$customer_id'";
    $result = mysqli_query($con, $query);

    if (!$result || mysqli_num_rows($result) == 0) {
        echo "Customer not found!";
        exit();
    }

    $customer = mysqli_fetch_assoc($result);
} else {
    echo "No customer ID provided!";
    exit();
}

// Update logic
if (isset($_POST['submit'])) {
    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $phone   = $_POST['phone'];
    $address = $_POST['address'];

    $update_query = "UPDATE customer SET name='$name', email='$email', phone='$phone', address='$address' WHERE cust_id='$customer_id'";

    if (mysqli_query($con, $update_query)) {
        header("Location: adview.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($con);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Customer</title>
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        body {
            background-color: #121212;
            color: #e0e0e0;
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .admin-container {
            display: flex;
        }

        .admin-content {
            flex-grow: 1;
            padding: 30px;
        }

        .form-container {
            background-color: #1a1a1a;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
            max-width: 600px;
            margin: auto;
            border: 1px solid #333;
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #e0e0e0;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #ddd;
        }

        input[type="text"], input[type="email"], textarea {
            width: 100%;
            padding: 10px;
            background: #2d2d2d;
            color: #fff;
            border: 1px solid #444;
            border-radius: 6px;
        }

        textarea {
            resize: vertical;
        }

        .btn {
            background-color: #333;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #444;
        }

        /* Sidebar buttons to match view page */
        .sidebar {
            background-color: #1a1a1a;
            width: 250px;
            min-height: 100vh;
            padding: 20px 0;
            border-right: 1px solid #333;
        }

        .admin-menu {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .admin-menu li {
            margin: 10px 0;
        }

        .admin-menu li a {
            display: block;
            padding: 12px 20px;
            color: #e0e0e0;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.2s ease;
        }

        .admin-menu li a:hover {
            background-color: #333;
        }

        .admin-menu li a span {
            margin-right: 10px;
        }

        .admin-brand {
            text-align: center;
            padding: 20px;
            color: #fff;
            font-size: 18px;
            border-bottom: 1px solid #333;
        }
    </style>
</head>
<body>

<div class="admin-container">

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="admin-brand">
            Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!
        </div>
        <ul class="admin-menu">
            <li><a href="adinsert.php"><span>➕</span> Insert New Record</a></li>
            <li><a href="adview.php"><span>📋</span> View Records</a></li>
            <li><a href="menu-list.php"><span>🍽️</span> Manage Menu</a></li>
            <li><a href="adminadd-employee.php"><span>👨‍💼</span> Add Employee</a></li>
            <li><a href="adminview-employees.php"><span>👥</span> View Employees</a></li>
            <li><a href="stats.php"><span>📊</span> Statistics</a></li>
            <li><a href="../logout.php"><span>🚪</span> Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="admin-content">
        <div class="form-container">
            <h2>Edit Customer</h2>
            <form action="edit_customer.php?id=<?php echo $customer_id; ?>" method="POST">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" name="name" id="name" value="<?php echo $customer['name']; ?>" required>
                </div>

                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" value="<?php echo $customer['email']; ?>" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone:</label>
                    <input type="text" name="phone" id="phone" value="<?php echo $customer['phone']; ?>" required>
                </div>

                <div class="form-group">
                    <label for="address">Address:</label>
                    <textarea name="address" id="address" rows="3" required><?php echo $customer['address']; ?></textarea>
                </div>

                <div style="text-align:center;">
                    <button type="submit" name="submit" class="btn">Update Customer</button>
                </div>
            </form>
        </div>
    </div>
</div>

</body>
</html>
