<?php
require_once('adminauth.php');
require_once('../dbcontroller.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$db = new DBController();

if (!isset($_GET['cat_id'])) {
    $_SESSION['error'] = "No category ID provided.";
    header("Location: categories.php");
    exit();
}

$cat_id = $_GET['cat_id'];
$category = $db->runQuery("SELECT * FROM categories WHERE cat_id = ?", "i", [$cat_id]);

if (!$category) {
    $_SESSION['error'] = "Category not found.";
    header("Location: categories.php");
    exit();
}

$category = $category[0];

// Handle update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $result = $db->preparedQuery("UPDATE categories SET name = ? WHERE cat_id = ?", "si", [$name, $cat_id]);
    $_SESSION[$result ? 'success' : 'error'] = $result ? "Category updated." : "Update failed.";
    header("Location: categories.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Category</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>
        <div class="admin-content">
            <h1>Edit Category</h1>

            <form method="POST" class="form">
                <label>Category Name</label>
                <input type="text" name="name" value="<?= htmlspecialchars($category['name']); ?>" required>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
</body>
</html>
