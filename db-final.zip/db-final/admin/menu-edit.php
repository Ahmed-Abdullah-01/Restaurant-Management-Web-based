<?php
require_once('../dbcontroller.php');
require_once('adminauth.php');

$db = new DBController();

// Get menu item code from URL parameter
$code = isset($_GET['code']) ? intval($_GET['code']) : 0;

// Get menu item details
$menuItem = $db->runQuery("SELECT * FROM menu WHERE code = ?", [$code], "i");
if (!$menuItem || count($menuItem) === 0) {
    $_SESSION['error'] = "Menu item not found";
    header("Location: menu-list.php");
    exit();
}
$menuItem = $menuItem[0];

// Get all categories
$categories = $db->runQuery("SELECT * FROM categories ORDER BY name");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $name = $_POST['name'];
        $cat_id = $_POST['cat_id'];
        $price = (float)$_POST['price'];
        $description = $_POST['description'];
        $image = $menuItem['image'];

        // Handle image upload
        if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
            $target_dir = "../images/menu/";
            $file_extension = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
            $new_image = uniqid() . '.' . $file_extension;
            $target_file = $target_dir . $new_image;
            
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                // Delete old image
                if ($image && file_exists($target_dir . $image)) {
                    unlink($target_dir . $image);
                }
                $image = $new_image;
            }
        }

        $stmt = $db->prepareQuery(
            "UPDATE menu SET 
                name = ?, 
                cat_id = ?, 
                price = ?, 
                description = ?, 
                image = ? 
            WHERE code = ?",
            [$name, $cat_id, $price, $description, $image, $code],
            "sidssi"  // string, integer, double, string, string, integer
        );

        $_SESSION['success'] = "Menu item updated successfully";
        header("Location: menu-list.php");
        exit();

    } catch (Exception $e) {
        $_SESSION['error'] = $e->getMessage();
        header("Location: menu-edit.php?code=$code");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Menu Item</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <?php include('includes/sidebar.php'); ?>

        <div class="admin-content">
            <div class="content-header">
                <h1 class="content-title">Edit Menu Item</h1>
                <p class="content-description">Update menu item details.</p>
            </div>

            <?php if (isset($_SESSION['error'])): ?>
                <div class='error'><?= htmlspecialchars($_SESSION['error']) ?></div>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name">Item Name</label>
                        <input type="text" id="name" name="name" 
                            value="<?= htmlspecialchars($menuItem['name']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="cat_id">Category</label>
                        <select id="cat_id" name="cat_id" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['cat_id'] ?>" 
                                    <?= ($category['cat_id'] == $menuItem['cat_id']) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($category['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                            
                    </div>

                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="number" id="price" name="price" step="0.01" 
                            value="<?= htmlspecialchars($menuItem['price']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4" required><?= 
                            htmlspecialchars($menuItem['description']) 
                        ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="image">Image</label>
                        <?php if ($menuItem['image']): ?>
                            <div class="current-image">
                                <img src="../images/menu/<?= htmlspecialchars($menuItem['image']) ?>" 
                                    alt="Current image" style="max-width: 200px;">
                                <p>Current image</p>
                            </div>
                        <?php endif; ?>
                        <input type="file" id="image" name="image" accept="image/*">
                    </div>

                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Update Menu Item</button>
                        <a href="menu-list.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>