<!-- Sidebar Navigation -->
<div class="sidebar">
    <div class="admin-brand">
        <h1>Admin Panel</h1>
    </div>
    <ul class="admin-menu">
        <li class="menu-section">Main</li>
        <li class="menu-item">
            <a href="control.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'control.php' ? 'active' : ''; ?>">
                <span class="menu-icon">📊</span>
                <span class="menu-text">Dashboard</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="adview.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'adview.php' ? 'active' : ''; ?>">
                <span class="menu-icon">👥</span>
                <span class="menu-text">View Records</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="adinsert.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'adinsert.php' ? 'active' : ''; ?>">
                <span class="menu-icon">➕</span>
                <span class="menu-text">Add Customer</span>
            </a>
        </li>

        <li class="menu-section">Menu Management</li>
        <li class="menu-item">
            <a href="menu-list.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'menu-list.php' ? 'active' : ''; ?>">
                <span class="menu-icon">🍽️</span>
                <span class="menu-text">Manage Menu</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="menu-add.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'menu-add.php' ? 'active' : ''; ?>">
                <span class="menu-icon">➕</span>
                <span class="menu-text">Add Menu Item</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="categories.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'categories.php' ? 'active' : ''; ?>">
                <span class="menu-icon">📑</span>
                <span class="menu-text">Categories</span>
            </a>
        </li>

        <li class="menu-section">Staff & Reports</li>
        <li class="menu-item">
            <a href="adminview-employees.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'adminview-employees.php' ? 'active' : ''; ?>">
                <span class="menu-icon">👨‍💼</span>
                <span class="menu-text">Employees</span>
            </a>
        </li>
        <li class="menu-item">
            <a href="stats.php" class="menu-link <?php echo basename($_SERVER['PHP_SELF']) == 'stats.php' ? 'active' : ''; ?>">
                <span class="menu-icon">📈</span>
                <span class="menu-text">Statistics</span>
            </a>
        </li>

        <li class="menu-section">Account</li>
        <li class="menu-item">
            <a href="../logout.php" class="menu-link">
                <span class="menu-icon">🚪</span>
                <span class="menu-text">Logout</span>
            </a>
        </li>
    </ul>
</div>

<!-- Toggle Button -->
<button class="toggle-btn" onclick="toggleSidebar()">☰</button> 