<?php
session_start();
require("dbcontroller.php");
require_once("db.php");

// Only require authentication for order placement
if(!empty($_GET["action"]) && $_GET["action"] == "insert") {
    if(!isset($_SESSION['email'])) {
        // Redirect to login page if not authenticated
        header("Location: login.php?redirect=menu.php");
        exit();
    }
    $email = $_SESSION['email'];
}

$db_handle = new DBController();
if(!empty($_GET["action"])) {
    switch($_GET["action"]) {
        case "add":
            if(!empty($_POST["quantity"])) {
                $productByCode = $db_handle->runQuery("SELECT * FROM menu WHERE code='" . $db_handle->sanitize($_GET["code"]) . "'");
                if(!empty($productByCode)) {
                    $itemArray = array(
                        $productByCode[0]["code"] => array(
                            'name' => $productByCode[0]["name"], 
                            'code' => $productByCode[0]["code"], 
                            'quantity' => $_POST["quantity"], 
                            'price' => $productByCode[0]["price"], 
                            'image' => $productByCode[0]["image"]
                        )
                    );
                    
                    if(!empty($_SESSION["cart_item"])) {
                        if(in_array($productByCode[0]["code"], array_keys($_SESSION["cart_item"]))) {
                            foreach($_SESSION["cart_item"] as $k => $v) {
                                if($productByCode[0]["code"] == $k) {
                                    if(empty($_SESSION["cart_item"][$k]["quantity"])) {
                                        $_SESSION["cart_item"][$k]["quantity"] = 0;
                                    }
                                    $_SESSION["cart_item"][$k]["quantity"] += $_POST["quantity"];
                                }
                            }
                        } else {
                            $_SESSION["cart_item"] = array_merge($_SESSION["cart_item"], $itemArray);
                        }
                    } else {
                        $_SESSION["cart_item"] = $itemArray;
                    }
                }
            }
        break;
        
        case "insert":
            if(!empty($_SESSION["cart_item"])) {
                $email = $_SESSION['email']; // Get email from session
                $custResult = $db_handle->runQuery("SELECT cust_id FROM customer WHERE email = '" . $db_handle->sanitize($email) . "'");
                
                if(!empty($custResult)) {
                    $cust_id = $custResult[0]['cust_id'];

                    // Calculate total for all items
                    $total_amount = 0;
                    foreach($_SESSION["cart_item"] as $item) {
                        $total_amount += $item["price"] * $item["quantity"];
                    }

                    // Insert into orders
                    $orderData = [
                        'cust_id' => $cust_id,
                        'total' => $total_amount,
                        'status' => 'completed'
                    ];
                    $done1 = $db_handle->insert('orders', $orderData);

                    // Get the new order id
                    $order_id = $db_handle->getLastInsertId();

                    // Insert items into order_items
                    foreach($_SESSION["cart_item"] as $k => $v) {
                        $orderItemData = [
                            'order_id' => $order_id,
                            'menu_code' => $v["code"],
                            'quantity' => $v["quantity"],
                            'price' => $v["price"]
                        ];
                        $db_handle->insert('order_items', $orderItemData);
                    }

                    // Clear the cart after successful order
                    unset($_SESSION["cart_item"]);
                }
            }
        break;
        
        case "remove":
            if(!empty($_SESSION["cart_item"])) {
                foreach($_SESSION["cart_item"] as $k => $v) {
                    if($_GET["code"] == $k)
                        unset($_SESSION["cart_item"][$k]);                
                    if(empty($_SESSION["cart_item"]))
                        unset($_SESSION["cart_item"]);
                }
            }
        break;
        
        case "empty":
            unset($_SESSION["cart_item"]);
        break;    
    }
}
?>
<html lang="en">

<head>
    <TITLE>Menu</TITLE>
    <link rel="stylesheet" href="css/shop.css" type="text/css" />
    <link href="//db.onlinewebfonts.com/c/465b1cbe35b5ca0de556720c955abece?family=AbolitionW00-Regular" rel="stylesheet"
        type="text/css" />
    <meta charset="utf-8">
    <script src="https://unpkg.com/scrollreveal"></script>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,700i&display=swap" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/shop.css">
    <link rel="stylesheet" href="css/button.css">
    <script>
    function myFunction() {
        document.getElementById("myP").style.visibility = "visible";
    }
    </script>
</head>

<body data-aos-easing="ease-out-back" data-aos-duration="1500" data-aos-delay="0">
    <nav class="navbar navbar-expand-md navbar-dark position-sticky-top fixed-top">
        <div class="canvas-area">
            <div class="head1">
                <a class="navbar-logo" href="#"><img src="img/logo.png"
                        style="height:35px; width: 214px;padding-top:1px"> </a></div>
            <div class="flot">
                <button class="navbar-toggler" type="button " style="float: right" data-toggle="collapse"
                    data-target="#navbarResponsive">
                    <span class="navbar-toggler-icon "></span>
                </button>
            </div>

            <div class="collapse navbar-collapse text-right" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">about</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">menu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reservation.php">reservation</a>
                    </li>
                    <?php if(isset($_SESSION['email'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">logout</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user.php">
                            <p><?php
                            $email = $_SESSION['email'];
                            $query1 = "SELECT name FROM customer WHERE email='" . $db_handle->sanitize($email) . "'";
                            $nameg = mysqli_query($con, $query1);
                            while ($row = mysqli_fetch_assoc($nameg)) {
                                echo htmlspecialchars($row['name']) . "<br>";
                            }?></p>
                        </a>
                    </li>
                    <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="registration.php">register</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    
    <div class="col-md-7" id="product-grid">
    <?php
    $product_array = $db_handle->runQuery("SELECT code, name, price, description, image FROM menu ORDER BY code ASC");
    if (!empty($product_array)):
        foreach($product_array as $key => $item):
    ?>
        <div class="container-fluid" id="prohov">
            <div class="product-item foo-2">
                <form method="post" action="menu.php?action=add&code=<?php echo htmlspecialchars($item["code"]); ?>">
                    <div class="product-image">
                        <img src="images/menu/<?php echo htmlspecialchars($item["image"]); ?>" 
                             style="height:155px; margin-left:15px; margin-top:10px; border-radius:80px;"
                             alt="<?php echo htmlspecialchars($item["name"]); ?>">
                    </div>

                    <div class="product-tile-footer">
                        <div class="product-title"><?php echo htmlspecialchars($item["name"]); ?></div>
                        <div class="product-description"><?php echo htmlspecialchars($item["description"]); ?></div>
                    </div>

                    <div class="lower">
                        <div class="cart-action">
                            <input type="text" class="product-quantity fix2" name="quantity" value="1" size="2" />
                            <input type="submit" value="Add to Cart" class="btnAddAction fix1" />
                        </div>
                    </div>
                    <div class="product-price"><?php echo "$" . htmlspecialchars($item["price"]); ?></div>
                </form>
            </div>
        </div>
    <?php
        endforeach;
    else:
        echo "<p>No products available.</p>";
    endif;
    ?>
    </div>

    <div class="right">
    <div id="shopping-cart">
        <div class="txt-heading">Shopping Cart</div>

        <?php
        if (isset($_SESSION["cart_item"])) {
            $total_quantity = 0;
            $total_price = 0;
        ?>
        <table class="tbl-cart" cellpadding="10" cellspacing="2" style="padding-top:10px;">
            <tbody>
                <tr>
                    <th style="text-align:left;" width="30%">Name</th>
                    <th style="text-align:right;" width="5%">Quantity</th>
                    <th style="text-align:right;" width="20%">Unit Price</th>
                    <th style="text-align:right;" width="10%">Price</th>
                    <th style="text-align:center;" width="5%">Remove</th>
                </tr>
                <?php
                foreach ($_SESSION["cart_item"] as $item) {
                    $item_price = $item["quantity"] * $item["price"];
                ?>
                <tr>
                    <td>
                        <img src="images/menu/<?php echo htmlspecialchars($item["image"]); ?>"
                             class="cart-item-image"
                             style="width:50px; height:50px; border-radius:8px; margin-right:10px; vertical-align:middle;" />
                        <?php echo htmlspecialchars($item["name"]); ?>
                    </td>
                    <td style="text-align:right;"><?php echo htmlspecialchars($item["quantity"]); ?></td>
                    <td style="text-align:right;"><?php echo "$ " . htmlspecialchars($item["price"]); ?></td>
                    <td style="text-align:right;"><?php echo "$ " . number_format($item_price, 2); ?></td>
                    <td style="text-align:center;">
                        <a href="menu.php?action=remove&code=<?php echo urlencode($item["code"]); ?>">
                            <img src="icon-delete.png" alt="Remove Item" />
                        </a>
                    </td>
                </tr>
                <?php
                    $total_quantity += $item["quantity"];
                    $total_price += $item_price;
                }
                ?>
                <tr>
                    <td colspan="2" align="right">Total:</td>
                    <td align="right"><?php echo $total_quantity; ?></td>
                    <td align="right" colspan="2">
                        <strong><?php echo "$ " . number_format($total_price, 2); ?></strong>
                    </td>
                </tr>
            </tbody>
        </table>

        <?php if(isset($_SESSION['email'])): ?>
            <a id="btnorder" href="menu.php?action=insert" onclick="myFunction()">Place Order</a>
        <?php else: ?>
            <a id="btnorder" href="login.php?redirect=menu.php">Login to Order</a>
        <?php endif; ?>
        
        <a id="btnEmpty" href="menu.php?action=empty">Empty Cart</a>
        <p id="myP" style="visibility: hidden; font-family:'Montserrat'; color:#d00000; float:left; text-decoration:none; margin-left: 20px !important; margin: 10px 0px;">
            Your orders have been placed
        </p>

        <?php
        } else {
        ?>
        <div class="no-records">Your Cart is Empty</div>
        <?php
        }
        ?>
    </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" 
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" 
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" 
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" 
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" 
        crossorigin="anonymous"></script>
    <footer>
        <p>
            Created with <i class="fa fa-heart"></i> by
            <a target="_blank" href="index.html">FOODILITE</a>
        </p>
    </footer>
</body>
</html>
