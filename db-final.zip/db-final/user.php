<?php 
require('db.php');
include("auth.php");
$email = $_SESSION['email'];

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Get customer name and ID
$query1 = "SELECT cust_id, name FROM customer WHERE email = ?";
$stmt = mysqli_prepare($con, $query1);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$name_result = mysqli_stmt_get_result($stmt);
$customer_name = "";
$customer_id = 0;
if ($row = mysqli_fetch_assoc($name_result)) {
    $customer_name = $row['name'];
    $customer_id = $row['cust_id'];
    error_log("Customer ID: " . $customer_id . ", Name: " . $customer_name);
} else {
    error_log("No customer found for email: " . $email);
}
mysqli_stmt_close($stmt);

// Debug: Check if tables exist and have data
$check_tables = "SHOW TABLES LIKE 'orders'";
$tables_result = mysqli_query($con, $check_tables);
if (mysqli_num_rows($tables_result) == 0) {
    error_log("Orders table does not exist!");
}

$check_tables = "SHOW TABLES LIKE 'reservation'";
$tables_result = mysqli_query($con, $check_tables);
if (mysqli_num_rows($tables_result) == 0) {
    error_log("Reservation table does not exist!");
}

// Debug: Check orders data
$debug_orders = "SELECT COUNT(*) as count FROM orders WHERE cust_id = ?";
$stmt = mysqli_prepare($con, $debug_orders);
mysqli_stmt_bind_param($stmt, "i", $customer_id);
mysqli_stmt_execute($stmt);
$count_result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($count_result);
error_log("Number of orders found: " . $row['count']);
mysqli_stmt_close($stmt);

// Debug: Check reservations data
$debug_reservations = "SELECT COUNT(*) as count FROM reservation r JOIN customer c ON r.cust_id = c.cust_id WHERE c.email = ?";
$stmt = mysqli_prepare($con, $debug_reservations);
mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);
$count_result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($count_result);
error_log("Number of reservations found: " . $row['count']);
mysqli_stmt_close($stmt);
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Foodilite|User Dashboard</title>
    <link href="//db.onlinewebfonts.com/c/465b1cbe35b5ca0de556720c955abece?family=AbolitionW00-Regular" rel="stylesheet"
        type="text/css" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/button.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <title>Foodilite</title>
</head>

<body data-aos-easing="ease-out-back" data-aos-duration="1500" data-aos-delay="0">
    <nav class="navbar navbar-expand-md navbar-dark position-sticky-top fixed-top">
        <div class="canvas-area">
            <div class="head1">
                <a class="navbar-logo" href="#"><img src="img/logo.png"
                        style="height:35px; width: 214px;padding-top:1px"> </a></div>
            <div class="flot">
                <button class="navbar-toggler" type="button " style="float: right" data-toggle="collapse"
                    data-target="#navbarResponsive">
                    <span class="navbar-toggler-icon "></span>
                </button>
            </div>

            <div class="collapse navbar-collapse text-right" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">about</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">menu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reservation.php">reservation</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">logout</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="user.php">
                            <p><?php echo htmlspecialchars($customer_name); ?></p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container-fluid">
        <div class="col-md-12">
            <p style="font-family: 'Beyond the mountains';text-transform:capitalize;color:black;margin-top:100px;text-align:center;font-size:40px">
                Welcome <?php echo htmlspecialchars($customer_name); ?>
            </p>
        </div>
    </div>
    <hr>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <p style="font-family:'AbolitionW00-Regular';font-size:30px;text-align:center;">Your past orders</p>
            </div>
            <div class="col-md-6">
                <p style="font-family:'AbolitionW00-Regular';font-size:30px;text-align:center;">Your upcoming reservations</p>
            </div>
        </div>

        <!-- Past Orders Table -->
        <div class="row">
            <div class="col-md-6">
                <table class="table table-bordered" style="margin-top:10px;">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Item Name</th>
                            <th>Quantity</th>
                            <th>Date</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $count = 1;
                        $orders_query = "SELECT m.name, oi.quantity, o.order_date, oi.price * oi.quantity as total
                                       FROM orders o
                                       JOIN order_items oi ON o.id = oi.order_id
                                       JOIN menu m ON oi.menu_code = m.code
                                       WHERE o.cust_id = ?
                                       ORDER BY o.order_date DESC";
                        
                        $stmt = mysqli_prepare($con, $orders_query);
                        if (!$stmt) {
                            error_log("Orders query prepare failed: " . mysqli_error($con));
                        }
                        mysqli_stmt_bind_param($stmt, "i", $customer_id);
                        if (!mysqli_stmt_execute($stmt)) {
                            error_log("Orders query execute failed: " . mysqli_stmt_error($stmt));
                        }
                        $orders_result = mysqli_stmt_get_result($stmt);
                        
                        if (!$orders_result) {
                            error_log("Orders query result failed: " . mysqli_error($con));
                        }
                        
                        while($row = mysqli_fetch_assoc($orders_result)) { ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                                <td><?php echo htmlspecialchars($row['order_date']); ?></td>
                                <td>₹<?php echo htmlspecialchars($row['total']); ?></td>
                            </tr>
                        <?php } 
                        mysqli_stmt_close($stmt);
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Upcoming Reservations Table -->
            <div class="col-md-6">
                <table class="table table-bordered" style="margin-top:10px;">
                    <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Reservation Date</th>
                            <th>Reservation Time</th>
                            <th>Number of Guests</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $count = 1;
                        $reservations_query = "SELECT r.res_date, r.res_time, r.no_of_ppl, r.status 
                                             FROM reservation r
                                             JOIN customer c ON r.cust_id = c.cust_id
                                             WHERE c.email = ? AND r.res_date >= CURDATE()
                                             ORDER BY r.res_date ASC, r.res_time ASC";
                        
                        $stmt = mysqli_prepare($con, $reservations_query);
                        if (!$stmt) {
                            error_log("Reservations query prepare failed: " . mysqli_error($con));
                        }
                        mysqli_stmt_bind_param($stmt, "s", $email);
                        if (!mysqli_stmt_execute($stmt)) {
                            error_log("Reservations query execute failed: " . mysqli_stmt_error($stmt));
                        }
                        $reservations_result = mysqli_stmt_get_result($stmt);
                        
                        if (!$reservations_result) {
                            error_log("Reservations query result failed: " . mysqli_error($con));
                        }
                        
                        while($row = mysqli_fetch_assoc($reservations_result)) { ?>
                            <tr>
                                <td><?php echo $count++; ?></td>
                                <td><?php echo htmlspecialchars($row['res_date']); ?></td>
                                <td><?php echo htmlspecialchars($row['res_time']); ?></td>
                                <td><?php echo htmlspecialchars($row['no_of_ppl']); ?></td>
                                <td><?php echo htmlspecialchars($row['status'] ?? 'Confirmed'); ?></td>
                            </tr>
                        <?php }
                        mysqli_stmt_close($stmt);
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer>
        <p>
            Created with <i class="fa fa-heart"></i> by
            <a target="_blank" href="index.html">FOODILITE</a>
        </p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script>
        AOS.init();
    </script>
</body>
</html>