-- Database: food
CREATE DATABASE IF NOT EXISTS `food`;
USE `food`;

-- Admin Table
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Employee Table (Critical Addition)
CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `position` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Categories Table
CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`cat_id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Customer Table
CREATE TABLE IF NOT EXISTS `customer` (
  `cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_login` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`cust_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Menu Table
CREATE TABLE IF NOT EXISTS `menu` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`code`),
  KEY `cat_id` (`cat_id`),
  CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`cat_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Orders Table
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cust_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'completed',
  PRIMARY KEY (`id`),
  KEY `cust_id` (`cust_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`cust_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Order Items Table
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `menu_code` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `menu_code` (`menu_code`),
  CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`menu_code`) REFERENCES `menu` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- VIP Table
CREATE TABLE IF NOT EXISTS `vip` (
  `vip_id` int(11) NOT NULL AUTO_INCREMENT,
  `vip_name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `price_multiplier` decimal(3,2) DEFAULT 1.00,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`vip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Reservation Table
CREATE TABLE IF NOT EXISTS `reservation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reservation_number` varchar(20) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `res_date` date NOT NULL,
  `res_time` time NOT NULL,
  `no_of_ppl` int(11) NOT NULL,
  `vip_id` int(11) DEFAULT NULL,
  `special_request` text DEFAULT NULL,
  `status` enum('pending','confirmed','cancelled','completed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reservation_number` (`reservation_number`),
  KEY `cust_id` (`cust_id`),
  KEY `vip_id` (`vip_id`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`cust_id`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`vip_id`) REFERENCES `vip` (`vip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample Data
INSERT INTO `admin` (`username`, `password`) VALUES
('admin', '5f4dcc3b5aa765d61d8327deb882cf99');

INSERT INTO `categories` (`name`, `description`, `display_order`) VALUES
('Appetizers', 'Delicious starters to begin your meal', 1),
('Main Courses', 'Hearty main dishes for every palate', 2),
('Desserts', 'Sweet treats to end your meal perfectly', 3),
('Drinks', 'Refreshing beverages to complement your food', 4);

INSERT INTO `customer` (`name`, `email`, `password`, `address`, `phone`) VALUES
('Admin User', 'admin@foodilite.com', '5f4dcc3b5aa765d61d8327deb882cf99', '123 Admin Street', '1234567890'),
('John Doe', 'john@example.com', '5f4dcc3b5aa765d61d8327deb882cf99', '456 Main St', '555-1234');

INSERT INTO `menu` (`name`, `price`, `cat_id`, `description`, `image`, `is_featured`) VALUES
('Margherita Pizza', 12.99, 2, 'Classic pizza with tomato sauce and mozzarella', 'dish-3.jpg', 1),
('Chicken Tikka Masala', 14.50, 2, 'Grilled chicken chunks in spiced curry sauce', 'dish-4.jpg', 1),
('Bruschetta', 6.99, 1, 'Toasted bread topped with tomatoes, garlic, and fresh basil', 'appetizer-1.jpg', 0),
('Chocolate Lava Cake', 7.99, 3, 'Warm chocolate cake with a molten center, served with vanilla ice cream', 'dessert-1.jpg', 1);

INSERT INTO `vip` (`vip_name`, `description`, `price_multiplier`) VALUES
('Standard', 'Regular seating', 1.00),
('Premium', 'Window seating with better views', 1.20),
('VIP Lounge', 'Private lounge area with dedicated service', 1.50);

-- Sample Orders Data
INSERT INTO `orders` (`cust_id`, `order_date`, `total`, `status`) VALUES
(2, '2024-01-15 18:30:00', 39.97, 'completed'),
(2, '2024-01-16 19:45:00', 28.50, 'completed');

INSERT INTO `order_items` (`order_id`, `menu_code`, `quantity`, `price`) VALUES
(1, 1, 2, 12.99),
(1, 4, 1, 7.99),
(2, 2, 2, 14.50);