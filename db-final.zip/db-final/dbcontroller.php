<?php
if (!class_exists('DBController')) {

class DBController {
    // Database configuration
    public $host = "localhost";
    public $user = "root";
    public $password = "";
    public $database = "food";
    public $conn;
    public $isConnected = false;

    public function __construct() {
        $this->conn = $this->connectDB();
        if($this->conn !== false) {
            $this->isConnected = true;
            $this->conn->set_charset("utf8mb4");
        }
    }

    private function connectDB() {
        try {
            $conn = new mysqli(
                $this->host,
                $this->user,
                $this->password,
                $this->database
            );

            if($conn->connect_errno) {
                throw new Exception(
                    "Connection failed: " . $conn->connect_error
                );
            }
            
            return $conn;
        } catch (Exception $e) {
            error_log($e->getMessage());
            $this->isConnected = false;
            return false;
        }
    }

    public function isConnected() {
        return $this->isConnected;
    }

    public function runQuery($query, $params = [], $types = "") {
        try {
            if(!empty($params)) {
                return $this->preparedQuery($query, $params, $types);
            }
            
            $result = $this->conn->query($query);
            
            if(!$result) {
                throw new Exception(
                    "Query Error: " . $this->conn->error . "\nQuery: " . $query
                );
            }

            return $this->formatResult($result);
        } catch (Exception $e) {
            error_log($e->getMessage());
            return false;
        }
    }

    private function preparedQuery($query, $params, $types) {
        $stmt = $this->conn->prepare($query);
        if(!$stmt) {
            throw new Exception(
                "Prepare failed: " . $this->conn->error . "\nQuery: " . $query
            );
        }

        if(!empty($params)) {
            if(empty($types)) {
                $types = $this->detectParamTypes($params);
            }
            $stmt->bind_param($types, ...$params);
        }

        if(!$stmt->execute()) {
            throw new Exception(
                "Execute failed: " . $stmt->error . "\nQuery: " . $query
            );
        }

        return $this->formatStatementResult($stmt);
    }

    private function detectParamTypes($params) {
        $types = '';
        foreach($params as $param) {
            switch(gettype($param)) {
                case 'integer': $types .= 'i'; break;
                case 'double':  $types .= 'd'; break;
                default:        $types .= 's'; break;
            }
        }
        return $types;
    }

    private function formatResult($result) {
        if($result instanceof mysqli_result) {
            $rows = [];
            while($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            $result->free();
            return $rows;
        }
        return $this->conn->affected_rows;
    }

    private function formatStatementResult($stmt) {
        $result = $stmt->get_result();
        if($result instanceof mysqli_result) {
            $rows = [];
            while($row = $result->fetch_assoc()) {
                $rows[] = $row;
            }
            $stmt->close();
            return $rows;
        }
        return $stmt->affected_rows;
    }

    public function getSingleValue($query, $params = [], $types = "") {
        $result = $this->runQuery($query, $params, $types);
        if(is_array($result) && !empty($result)) {
            return reset($result[0]);
        }
        return false;
    }

    public function insert($table, $data) {
        $columns = implode(', ', array_keys($data));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $values = array_values($data);
        $types = $this->detectParamTypes($values);

        $query = "INSERT INTO $table ($columns) VALUES ($placeholders)";
        return $this->runQuery($query, $values, $types);
    }

    public function update($table, $data, $where, $whereParams = [], $types = "") {
        $setClause = implode(' = ?, ', array_keys($data)) . ' = ?';
        $values = array_values($data);
        $values = array_merge($values, $whereParams);
        
        if(empty($types)) {
            $types = $this->detectParamTypes($values);
        }

        $query = "UPDATE $table SET $setClause WHERE $where";
        return $this->runQuery($query, $values, $types);
    }

    public function getLastInsertId() {
        return $this->conn->insert_id;
    }

    public function beginTransaction() {
        return $this->conn->begin_transaction();
    }

    public function commit() {
        return $this->conn->commit();
    }

    public function rollback() {
        return $this->conn->rollback();
    }

    public function close() {
        if($this->isConnected) {
            $this->conn->close();
            $this->isConnected = false;
        }
    }

    public function sanitize($input) {
        if(is_array($input)) {
            return array_map([$this, 'sanitize'], $input);
        }
        return $this->conn->real_escape_string(htmlspecialchars(trim($input)));
    }

    // Backward compatibility aliases
    public function executeQuery($query) { return $this->runQuery($query); }
    public function insq($query) { return $this->runQuery($query); }
    public function prepareQuery($query, $params = [], $types = "") { 
        return $this->runQuery($query, $params, $types); 
    }
}

} // End class_exists check
?>