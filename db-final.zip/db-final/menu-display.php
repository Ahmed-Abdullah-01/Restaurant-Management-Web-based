<?php
include('dbcontroller.php');

// Get all menu items grouped by category
$sql = "SELECT * FROM menu ORDER BY category, name";
$result = mysqli_query($conn, $sql);

$menuItems = [];
while($row = mysqli_fetch_assoc($result)) {
    $menuItems[$row['category']][] = $row;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Our Menu</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/shop.css">
</head>
<body>
    <?php include('menu.php'); ?>
    
    <div class="container">
        <h1>Our Menu</h1>
        
        <?php foreach($menuItems as $category => $items): ?>
            <div class="menu-category">
                <h2><?php echo htmlspecialchars($category); ?></h2>
                <div class="menu-items">
                    <?php foreach($items as $item): ?>
                        <div class="menu-item">
                            <?php if($item['image']): ?>
                                <img src="product-images/<?php echo $item['image']; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
                            <?php endif; ?>
                            <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                            <p class="price">$<?php echo number_format($item['price'], 2); ?></p>
                            <p class="description"><?php echo htmlspecialchars($item['description']); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
    
    <?php include('footer.php'); ?>
</body>
</html>